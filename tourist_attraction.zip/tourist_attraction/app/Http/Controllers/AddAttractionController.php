<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attraction;
use Illuminate\Support\Facades\Storage;

class AddAttractionController extends Controller
{
    public function adminIndex()
    {
        $attractions = Attraction::all();
        return view('attraction_add', compact('attractions'));

    }

     // Add this at the top of your controller

     public function addAttraction(Request $request)
     {
         // Create a new Attraction instance
         $attraction = new Attraction();
         $attraction->attraction_name = $request->input('attraction_name');
         $attraction->location = $request->input('location');
         $attraction->description = $request->input('description');
         $attraction->category = $request->input('category');
         $attraction->opening_hours = $request->input('opening_hours');
         $attraction->contact_number = $request->input('contact_number');
         $attraction->Facebook_page = $request->input('Facebook_page');
         $attraction->email_address = $request->input('email_address');
         $attraction->website = $request->input('website');
     
         // Handle file upload if a picture is provided
         if ($request->hasFile('picture')) {
             $picture = $request->file('picture');
             $pictureName = time() . '_' . $picture->getClientOriginalName();
             $picture->move(public_path('attraction_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
     
             // Store the picture path in the model
             $attraction->picture = 'attraction_pictures/' . $pictureName;
         }
     
         // Save the attraction to the database
         $attraction->save();
     
         // Redirect back or return a success response
         return redirect()->back()->with('success', 'Attraction added successfully.');
     }
}
