<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuisine;

class CuisineAdminController extends Controller
{
    public function adminIndex()
    {
        $cuisine = Cuisine::all();
        return view('cuisine_admin', compact('cuisine'));

    }
}
