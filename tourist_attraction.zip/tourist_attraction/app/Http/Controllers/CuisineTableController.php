<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuisine;

class CuisineTableController extends Controller
{
    public function adminIndex()
    {
        $cuisines = Cuisine::all();
        return view('cuisine_table', compact('cuisines'));

    }

    public function edit(Request $request)
    {
        $id = $request->input('cuisine_id');
        $cuisines = Cuisine::all();
        $cuisineToEdit = Cuisine::findOrFail($id);
        return view('cuisine_add', compact('cuisines', 'cuisineToEdit'));
    }
    
    public function update(Request $request, $cuisine_id)
{
    try {
        $cuisine = Cuisine::findOrFail($cuisine_id);
        if ($request->hasFile('picture')) {
            $picture = $request->file('picture');
            $pictureName = time() . '_' . $picture->getClientOriginalName();
            $picture->move(public_path('cuisine_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
    
            // Store the picture path in the model
            $cuisine->picture = 'cuisine_pictures/' . $pictureName;
        }
        $cuisine->update($request->all());


        return redirect()->route('cuisine_table')->with('success', 'Cuisine updated successfully');
    } catch (\Exception $e) {
        return redirect()->route('cuisine_table')->with('error', 'Error updating Cuisine');
    }
}

    public function destroy(Cuisine $cuisine)
    {
        // Delete the schedule from the database
        $cuisine->delete();

        // Redirect back or return a success response
        return redirect()->back()->with('success', 'Cuisine deleted successfully.');
    }
}
