<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hotels;

class HotelsTableController extends Controller
{
    public function adminIndex()
    {
        $hotels = Hotels::all();
        return view('hotels_table', compact('hotels'));

    }

    public function edit(Request $request)
    {
        $id = $request->input('hotels_id');
        $hotels = Hotels::all();
        $hotelsToEdit = Hotels::findOrFail($id);
        return view('hotels_add', compact('hotels', 'hotelsToEdit'));
    }
    

    public function update(Request $request, $hotels_id)
{
    try {
        $hotel = Hotels::findOrFail($hotels_id);
        if ($request->hasFile('picture')) {
            $picture = $request->file('picture');
            $pictureName = time() . '_' . $picture->getClientOriginalName();
            $picture->move(public_path('hotel_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
    
            // Store the picture path in the model
            $hotel->picture = 'hotel_pictures/' . $pictureName;
        }
        $hotel->update($request->all());


        return redirect()->route('hotels_table')->with('success', 'Hotel updated successfully');
    } catch (\Exception $e) {
        return redirect()->route('hotels_table')->with('error', 'Error updating Hotel');
    }
}

    public function destroy(Hotels $hotel)
    {
        // Delete the schedule from the database
        $hotel->delete();

        // Redirect back or return a success response
        return redirect()->back()->with('success', 'Hotel deleted successfully.');
    }
}
