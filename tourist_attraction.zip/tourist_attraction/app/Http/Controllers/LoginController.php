<?php

namespace App\Http\Controllers;
use App\Models\Accounts;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index()
    {
        if (!session()->has('logged_in') || !session('logged_in')) {
            return view('home_admin');
        }


        // If not logged in, show the login form
        return view('home');
    }
    public function showLogin()
    {
        // If not logged in, show the login form
        return view('login');
    }

    public function login(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        // Retrieve the user from the database based on the username
        $user = Accounts::where('username', $request->username)->first();

        // Check if the user exists and if the password matches
        if ($user && $request->password === $user->password) {
            // Set logged_in session and redirect to dashboard
            session(['logged_in' => true]);
            return redirect()->route('login');
        }

        // If credentials are invalid, redirect back with error message
        return redirect()->back()->withInput()->withErrors(['error' => 'Invalid credentials']);
    }


    public function dashboard()
    {
        if (!session()->has('logged_in') || !session('logged_in')) {
            return redirect()->route('dashboard');
        }

        return view('home');
    }

    public function logout()
    {
        session()->forget('logged_in');
        return view('home');
    }
}