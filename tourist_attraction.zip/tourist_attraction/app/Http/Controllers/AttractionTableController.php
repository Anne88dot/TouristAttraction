<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attraction;

class AttractionTableController extends Controller
{
    public function adminIndex()
    {
        $attractions = Attraction::all();
        return view('attraction_table', compact('attractions'));

    }

    public function edit(Request $request)
    {
        $id = $request->input('attraction_id');
        $attractions = Attraction::all();
        $attractionsToEdit = Attraction::findOrFail($id);
        return view('attraction_add', compact('attractions', 'attractionsToEdit'));
    }
    

    public function update(Request $request, $attraction_id)
{
    try {
        $attraction = Attraction::findOrFail($attraction_id);
        if ($request->hasFile('picture')) {
            $picture = $request->file('picture');
            $pictureName = time() . '_' . $picture->getClientOriginalName();
            $picture->move(public_path('attraction_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
    
            // Store the picture path in the model
            $attraction->picture = 'attraction_pictures/' . $pictureName;
        }
        $attraction->update($request->all());


        return redirect()->route('attractions_table')->with('success', 'Attraction updated successfully');
    } catch (\Exception $e) {
        return redirect()->route('attraction_table')->with('error', 'Error updating Attraction');
    }
}


    public function destroy(Attraction $attraction)
    {
        // Delete the schedule from the database
        $attraction->delete();

        // Redirect back or return a success response
        return redirect()->back()->with('success', 'Attraction deleted successfully.');
    }
}
