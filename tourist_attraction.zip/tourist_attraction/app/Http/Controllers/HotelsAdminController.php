<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hotels;


class HotelsAdminController extends Controller
{
    public function adminIndex()
    {
        $hotels = Hotels::all();
        return view('hotels_admin', compact('hotels'));

    }
}
