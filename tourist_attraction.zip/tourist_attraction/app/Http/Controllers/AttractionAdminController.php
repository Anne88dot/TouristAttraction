<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Attraction;

class AttractionAdminController extends Controller
{
    
    public function adminIndex()
    {
        $attractions = Attraction::all();
        return view('attraction_admin', compact('attractions'));

    }
}
