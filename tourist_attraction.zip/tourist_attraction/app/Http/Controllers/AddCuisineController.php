<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuisine;

class AddCuisineController extends Controller
{
    public function adminIndex()
    {
        $cuisines = Cuisine::all();
        return view('cuisine_add', compact('cuisines'));

    }

    public function addCuisine(Request $request)
     {
         // Create a new Attraction instance
         $cuisine = new Cuisine();
         $cuisine->cuisine_name = $request->input('cuisine_name');
         $cuisine->location = $request->input('location');
         $cuisine->description = $request->input('description');
         $cuisine->detail = $request->input('detail');
         $cuisine->reviews = $request->input('reviews');
     
         // Handle file upload if a picture is provided
         if ($request->hasFile('picture')) {
             $picture = $request->file('picture');
             $pictureName = time() . '_' . $picture->getClientOriginalName();
             $picture->move(public_path('cuisine_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
     
             // Store the picture path in the model
             $cuisine->picture = 'cuisine_pictures/' . $pictureName;
         }
     
         // Save the attraction to the database
         $cuisine->save();
     
         // Redirect back or return a success response
         return redirect()->back()->with('success', 'Cuisine added successfully.');
     }
}
