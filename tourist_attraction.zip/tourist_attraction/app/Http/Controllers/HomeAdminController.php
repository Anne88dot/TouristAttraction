<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hotels;

class HomeAdminController extends Controller
{
    
    public function dashboard()
    {
        if (!session()->has('logged_in') || !session('logged_in')) {
            return redirect()->route('login');
        }

        return view('home_admin');
    }
}
