<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cuisine;

class CuisineController extends Controller
{
    public function index()
    {
        $cuisine = Cuisine::all();
        return view('cuisine', compact('cuisine'));

    }
}
