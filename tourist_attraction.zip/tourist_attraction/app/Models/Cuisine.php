<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cuisine extends Model
{
    use HasFactory;

    protected $table = 'cuisine';
    protected $primaryKey = 'cuisine_id';
    protected $fillable = [
        'cuisine_name',
        'location',
        'description',
        'detail',
        'reviews',
        'picture'
    ];
}
