<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hotels;
use Illuminate\Support\Facades\Storage;

class AddHotelsController extends Controller
{
    public function adminIndex()
    {
        $hotels = Hotels::all();
        return view('hotels_add', compact('hotels'));

    }

    public function addHotels(Request $request)
     {
         // Create a new Attraction instance
         $hotel = new Hotels();
         $hotel->hotel_name = $request->input('hotel_name');
         $hotel->location = $request->input('location');
         $hotel->description = $request->input('description');
         $hotel->price = $request->input('price');
         $hotel->reviews = $request->input('reviews');
         $hotel->picture = $request->input('picture');
     
         // Handle file upload if a picture is provided
         if ($request->hasFile('picture')) {
             $picture = $request->file('picture');
             $pictureName = time() . '_' . $picture->getClientOriginalName();
             $picture->move(public_path('hotel_pictures'), $pictureName); // Move the picture to public/attraction_pictures folder
     
             // Store the picture path in the model
             $hotel->picture = 'hotel_pictures/' . $pictureName;
         }
     
         // Save the attraction to the database
         $hotel->save();
     
         // Redirect back or return a success response
         return redirect()->back()->with('success', 'Hotel added successfully.');
     }
}
