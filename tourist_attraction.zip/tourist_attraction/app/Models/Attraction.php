<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Attraction extends Model
{
    use HasFactory;
    protected $primaryKey = 'attraction_id';
    protected $table = 'attraction';
    protected $fillable = [
        'attraction_name',
        'location',
        'description',
        'category',
        'opening_hours',
        'contact_number',
        'Facebook_page',
        'email_address',
        'website'
    ];
}
